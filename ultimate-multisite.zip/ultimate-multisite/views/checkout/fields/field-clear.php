<?php
/**
 * Clear field view.
 *
 * @since 2.0.0
 */
defined( 'ABSPATH' ) || exit;

?>
<span class="wu-clear-both wu-block"></span>
