<?php
/**
 * Login Form
 *
 * @since 2.0.0
 */
defined( 'ABSPATH' ) || exit;

?>
<div class="wu-styling <?php echo esc_attr($className); ?>">

	<?php $form->render(); ?>

</div>
